﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Student
{
    class StudentAccess
    {
        static void Main(string[] args)
        {
            StudentFess sf = new StudentFess();
            Console.WriteLine("Enter Id ,Enter Name , Fesss");
            StudentDetails std1 = new StudentDetails();
            std1.Id = Convert.ToInt32(Console.ReadLine());
            std1.Name = Console.ReadLine();
            std1.Fess = Convert.ToInt32(Console.ReadLine());
            sf.AddStudent(std1);

            Console.WriteLine("Enter Id ,Enter Name , Fesss");
            StudentDetails std2 = new StudentDetails();
            std2.Id = Convert.ToInt32(Console.ReadLine());
            std2.Name = Console.ReadLine();
            std2.Fess = Convert.ToInt32(Console.ReadLine());
            sf.AddStudent(std2);

            Console.WriteLine("Enter Id ,Enter Name , Fesss");
            StudentDetails std3 = new StudentDetails();
            std3.Id = Convert.ToInt32(Console.ReadLine());
            std3.Name = Console.ReadLine();
            std3.Fess = Convert.ToInt32(Console.ReadLine());
            sf.AddStudent(std3);

            Console.WriteLine("Enter Id ,Enter Name , Fesss");
            StudentDetails std4 = new StudentDetails();
            std4.Id = Convert.ToInt32(Console.ReadLine());
            std4.Name = Console.ReadLine();
            std4.Fess = Convert.ToInt32(Console.ReadLine());
            sf.AddStudent(std4);

            List<StudentDetails> studentslist = sf.students();

            foreach(var item in studentslist)
            {
                Console.WriteLine($"{item.Id}  {item.Name}  {item.Fess}");

            }
            Console.WriteLine("Enter id to Remove");
            int id = Convert.ToInt32(Console.ReadLine());
            sf.DeleteStudent(id);

            studentslist = sf.students();

            foreach (var item in studentslist)
            {
                Console.WriteLine($"{item.Id}  {item.Name}  {item.Fess}");

            }


            Console.WriteLine("Enter the Modify Student");
            StudentDetails studdet1 = new StudentDetails();

            studdet1.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Name & Fess");
            studdet1.Name = Console.ReadLine();
            studdet1.Fess = Convert.ToInt32(Console.ReadLine());

            studentslist = sf.students();
           

            foreach (var item in studentslist)
            {
                Console.WriteLine($"{item.Id}  {item.Name}  {item.Fess}");

            }
            Console.WriteLine("Fess greater than 2000");

            studentslist = sf.FessStudent();


            foreach (var item in studentslist)
            {
                Console.WriteLine($"{item.Id}  {item.Name}  {item.Fess}");

            }
            Console.WriteLine("");
             

        }
    }
}
