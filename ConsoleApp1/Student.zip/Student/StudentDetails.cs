﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Student
{
    public class StudentDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Fess { get; set; }


    }
    public class StudentFess
    {
        private List<StudentDetails> Studentslist = null;
        public StudentFess()
        {
            Studentslist = new List<StudentDetails>();


        }
        public void AddStudent(StudentDetails stud)
        {
            Studentslist.Add(stud);
        }

        public void UpdateStudent(StudentDetails stud)
        {
            foreach (StudentDetails item in Studentslist)
            {
                if (item.Id == stud.Id)
                {
                    item.Name = stud.Name;
                    item.Fess = stud.Fess;
                    break;
                }

            }
        }
        public void DeleteStudent(int id)
        {
            foreach (StudentDetails item in Studentslist)
            {
                if (item.Id == id)
                {
                    Studentslist.Remove(item);
                    break;

                }
            }
        }
        public List<StudentDetails> FessStudent()
        {
            List<StudentDetails> stufeelist = new List<StudentDetails>();
            foreach (var item in stufeelist)
            {
                if (item.Fess > 2000)
                    stufeelist.Add(item);
            }
            return stufeelist;
        }
        public List<StudentDetails> students()
        {
            return Studentslist;
        }
    }
}
